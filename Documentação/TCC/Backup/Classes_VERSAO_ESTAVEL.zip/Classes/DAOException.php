<?php

	class DAOException extends Exception{
		
	} 







?>